using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Zakharov.Views.Journal
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
