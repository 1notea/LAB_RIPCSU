using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Zakharov.Views
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
